# azpy
Pythonic Azure
